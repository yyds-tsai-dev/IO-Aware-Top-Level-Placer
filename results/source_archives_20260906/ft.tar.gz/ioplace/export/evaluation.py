"""Portable evaluator evidence, aligned by net name and exact region geometry.

The NPZ is deliberately separate from the placement snapshot: an old snapshot
containing only x/y is not evidence of per-net evaluation. No pickle is used.
"""
import hashlib
import json
import os
import tempfile

import numpy as np


SCHEMA_VERSION = 1
PER_NET_FIELDS = (
    "per_net_crossings", "per_net_ft", "per_net_lambda",
    "per_net_steiner", "per_net_home",
)


def array_digest(*arrays):
    digest = hashlib.sha256()
    for value in arrays:
        arr = np.ascontiguousarray(value)
        digest.update(str(arr.dtype).encode())
        digest.update(str(arr.shape).encode())
        digest.update(memoryview(arr).cast("B"))
    return digest.hexdigest()


def region_digest(rg):
    return array_digest(np.asarray(rg.die, dtype=np.float64), rg.grid)


def normalized_names(names):
    return np.asarray([v.decode("utf-8") if isinstance(v, bytes) else str(v)
                       for v in names], dtype=np.str_)


def save_evaluation(path, nl, rg, result, node_x, node_y, net_names, *,
                    max_degree=256, provenance=None):
    """Persist an already computed result and its pin-region membership.

    Coordinates are in evaluator units (after PlaceDB scaling, when used by a
    driver). The net order and lattice fingerprints prevent accidental pairing
    across K, netlist versions, or independent placements.
    """
    names = normalized_names(net_names)
    if names.shape != (nl.num_nets,) or len(set(names)) != nl.num_nets:
        raise ValueError("net names must be unique and aligned to all nets")
    x = np.asarray(node_x[:nl.num_physical], dtype=np.float64)
    y = np.asarray(node_y[:nl.num_physical], dtype=np.float64)
    arrays = {key: np.asarray(getattr(result, key)) for key in PER_NET_FIELDS}
    if any(value.shape != (nl.num_nets,) for value in arrays.values()):
        raise ValueError("evaluator per-net arrays must cover the entire netlist")
    pairs = sorted(result.boundary_pair_demand)
    arrays.update(
        net_names=names,
        net_degrees=np.asarray(nl.net_degrees, dtype=np.int32),
        pin_region_mask=rg.pin_region_bitmask(nl, x, y),
        node_region=rg.region_of_points(x, y),
        boundary_pairs=np.asarray(pairs, dtype=np.int32).reshape(-1, 2),
        boundary_demand=np.asarray([result.boundary_pair_demand[p] for p in pairs],
                                   dtype=np.int64),
    )
    metadata = dict(
        schema_version=SCHEMA_VERSION, num_nets=nl.num_nets,
        num_physical=nl.num_physical, num_movable=nl.num_movable,
        k=rg.k, max_degree=int(max_degree), region_sha256=region_digest(rg),
        placement_sha256=array_digest(x, y),
        net_order_sha256=array_digest(names),
        node_region_convention="lower_left_position",
        totals={key: getattr(result, key) for key in
                ("io_count", "ft_count", "hard_lambda_sum", "io_rg", "ft_rg",
                 "tree_wl", "hpwl", "large_net_lb")},
        provenance=provenance or {},
    )
    arrays["metadata"] = np.asarray(json.dumps(metadata, sort_keys=True))
    parent = os.path.dirname(os.path.abspath(path))
    os.makedirs(parent, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".evaluation-", suffix=".npz", dir=parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            np.savez_compressed(stream, **arrays)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return metadata


def load_evaluation(path, *, net_names=None, rg=None):
    with np.load(path, allow_pickle=False) as archive:
        data = {key: archive[key] for key in archive.files}
    metadata = json.loads(str(data.pop("metadata")))
    if metadata.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unsupported evaluator evidence schema")
    n = metadata["num_nets"]
    for key in (*PER_NET_FIELDS, "net_degrees", "pin_region_mask", "net_names"):
        if key not in data or data[key].shape != (n,):
            raise ValueError(f"invalid evaluator evidence array: {key}")
    if array_digest(data["net_names"]) != metadata["net_order_sha256"]:
        raise ValueError("evaluator net-order fingerprint mismatch")
    for key, total in (("per_net_crossings", "io_count"),
                       ("per_net_ft", "ft_count"), ("per_net_steiner", "io_rg")):
        if int(data[key].sum(dtype=np.int64)) != metadata["totals"][total]:
            raise ValueError(f"evaluator total mismatch: {key}")
    if net_names is not None and not np.array_equal(normalized_names(net_names), data["net_names"]):
        raise ValueError("evaluator and route net-name orders differ")
    if rg is not None and region_digest(rg) != metadata["region_sha256"]:
        raise ValueError("evaluator and route region geometries differ")
    data["metadata"] = metadata
    return data


def pin_regions_from_evaluation(data):
    """Return all nets, including empty sets, so route FT has no missing sentinel."""
    k = data["metadata"]["k"]
    return {i: [r for r in range(k) if int(mask) & (1 << r)]
            for i, mask in enumerate(data["pin_region_mask"])}
