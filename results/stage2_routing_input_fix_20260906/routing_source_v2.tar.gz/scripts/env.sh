# Source this file from Bash: source /path/to/IO-Aware-Top-Level-Placer/scripts/env.sh
# Keep host paths in one place; callers can override the installation or Python.
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
    printf '%s\n' 'Use: source scripts/env.sh' >&2
    exit 1
fi

export IOPLACE_REPO="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export DREAMPLACE_ROOT="${DREAMPLACE_ROOT:-$(dirname -- "$IOPLACE_REPO")/DREAMPlace}"
export IOPLACE_PYTHON="${IOPLACE_PYTHON:-$DREAMPLACE_ROOT/.venv312/bin/python}"
export PYTHONPATH="$IOPLACE_REPO${PYTHONPATH:+:$PYTHONPATH}"

if [[ -x "$DREAMPLACE_ROOT/deps/cuda-12.8/bin/nvcc" ]]; then
    export CUDA_HOME="${CUDA_HOME:-$DREAMPLACE_ROOT/deps/cuda-12.8}"
    export CUDACXX="$CUDA_HOME/bin/nvcc"
    export PATH="$CUDA_HOME/bin:$PATH"
fi
if [[ -x "$DREAMPLACE_ROOT/deps/tools/usr/bin/bison" ]]; then
    export BISON_PKGDATADIR="$DREAMPLACE_ROOT/deps/tools/usr/share/bison"
    export PATH="$DREAMPLACE_ROOT/deps/tools/usr/bin:$PATH"
fi

# CUDA_VISIBLE_DEVICES is intentionally supplied by the caller on shared hosts.
