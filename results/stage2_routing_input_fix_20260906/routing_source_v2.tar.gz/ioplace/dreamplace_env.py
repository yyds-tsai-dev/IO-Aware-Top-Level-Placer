import os, sys
from pathlib import Path

DEFAULT_ROOT = str(Path(__file__).resolve().parents[2] / "DREAMPlace")

def setup_dreamplace(root=None):
    root = root or os.environ.get("DREAMPLACE_ROOT", DEFAULT_ROOT)
    for p in (os.path.join(root, "install"), os.path.join(root, "install", "dreamplace")):
        if p not in sys.path:
            sys.path.insert(0, p)
    return root
